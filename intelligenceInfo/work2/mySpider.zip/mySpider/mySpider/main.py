from scrapy import cmdline

# cmdline.execute("scrawl crawl taoche --nolog".split())
cmdline.execute("scrapy crawl migu".split())
